$dbname = "fbdb"; // Change this to your database name
$username_db = "vamsi"; // Change this to your database username
$password_db = "082002"; // Change this to your database password
$servername = "localhost";
